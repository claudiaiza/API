

/* select para buscar pokemon */
function loadEvents ()
{
   s = document.getElementById('search');
   f = document.getElementById('image');
   p = document.getElementById('Info_Pokemon');
   s.addEventListener('click', loadpokemon);
   page=0;
   Name = document.getElementById('Name_Pokemon')

   b = document.getElementById('buttonsearch');
   inp = document.getElementById('searchinput')
   b.addEventListener('click', loadpoke);
   page=0;
   
   var xmlhttp = new XMLHttpRequest();
   xmlhttp.onreadystatechange= countpoke;  
   xmlhttp.open("GET", 'https://pokeapi.co/api/v2/pokemon/');
   xmlhttp.send();
}
function loadJSON()
{
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = processJSON;
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/pokemon/?offset='+ page +'&limit='+counter );
	xmlhttp.send();
}
function loadpokemon()
{
   
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = NamePoke;
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/pokemon/'+ s.value);
	xmlhttp.send();
	
}
function processJSON ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);

      for(i =0; i<m.results.length;i++)
      {
        	op = document.createElement('option');
        	op.value = i + 1;
        	op.innerHTML = m.results[i].name;
        	s.appendChild(op);
      }
   }
}
function NamePoke()
{
	if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
		Name.innerHTML = m.name;
      f.innerHTML= "<img src =' " + m.sprites.front_default + "'id = 'imgpoke'>";
      p.innerHTML = " ";
      p.innerHTML = "  ⇾ Height: " + m.height + "<br>" + "  ⇾ Weight: " + m.weight + "<br>";
      for(i =0; i<m.types.length;i++)
      {
         p.innerHTML += "  ⇾ Types: " + m.types[i].type.name + "<br>";
      }
      for(i =0; i<m.abilities.length;i++)
      {
         p.innerHTML += "  ⇾ Abilities: " + m.abilities[i].ability.name + "<br>";
      }
      var xmlhttp=new XMLHttpRequest();
	   xmlhttp.onreadystatechange = loadhabitat;
	   xmlhttp.open("GET", m.species.url);
	   xmlhttp.send();
	}
}
function countpoke()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
		counter = m.count;
		loadJSON();
	}	
}
/* habitats */

function loadhabitat ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
      p.innerHTML += "  ⇾ Habitat: " + m.habitat.name;
   }
}


/* input para escribir yo el pokemon */

function manual ()
{
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/pokemon/?offset='+ page +'&limit='+counter );
	xmlhttp.send();
}
function loadpoke ()
{
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = NamePoke;
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/pokemon/'+ inp.value);
	xmlhttp.send();
}

function countpoke2()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
		counter = m.count;
		manual();
	}	
}


/* item */

function loadEvents3 ()
{
   sel = document.getElementById('it');
   p = document.getElementById('imagenitem');
   t = document.getElementById('cate');
   sel.addEventListener('click', loaditems);
   page=0;
   NameItem = document.getElementById('Name_Items')
   var xmlhttp = new XMLHttpRequest();
   xmlhttp.onreadystatechange= countitem;  
   xmlhttp.open("GET", 'https://pokeapi.co/api/v2/item/');
   xmlhttp.send();
}

function loadJSON2()
{
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = processJSON3;
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/item/?offset='+ page +'&limit='+counter );
	xmlhttp.send();
}

function loaditems()

{
   
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = infoitem;
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/item/' + sel.value);
	xmlhttp.send();
	
}
function processJSON3 ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);

      for(i =0; i<m.results.length;i++)
      {
        	opit = document.createElement('option');
        	opit.value = i + 1;
        	opit.innerHTML = m.results[i].name;
        	sel.appendChild(opit);
      }
   }
}
function infoitem()
{
	if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
		NameItem.innerHTML = m.name;
      p.innerHTML= "<img src =' " + m.sprites.default + "'id = 'imgitem'>";
      t.innerHTML = " ";
      t.innerHTML = "  ⇾ Category: " + m.category.name + "<br>";
      for(i =0; i<m.effect_entries.length;i++)
      {
         t.innerHTML +=  "  ⇾ Effect Entries: " + m.effect_entries[i].effect + "<br>";
      }
      for(i =0; i<m.held_by_pokemon.length;i++)
      {
         t.innerHTML +=  "  ⇾ Held by: " + m.held_by_pokemon[i].pokemon.name + "<br>";
      }

	}
}

function countitem()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
		counter = m.count;
		loadJSON2();
	}	
}

/* selects conectados */

function loadEvents4 ()
{
   sh = document.getElementById('selhab');
   sp = document.getElementById ('selpok');
   sh.addEventListener('click', loadhabilities);
   sp.addEventListener('click', showinfo);
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = counthab;
	xmlhttp.open("GET",' https://pokeapi.co/api/v2/ability/');
	xmlhttp.send();
}


function page ()
{
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = processJSON4;
	xmlhttp.open("GET",' https://pokeapi.co/api/v2/ability/?offset='+ page +'&limit='+ cont);
	xmlhttp.send();
}



function loadhabilities ()
{
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = listpoke;
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/ability/' + sh.value);
	xmlhttp.send();
}

function processJSON4 ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);

      for(i =0; i<m.results.length;i++)
      {
        	ot1 = document.createElement('option');
        	ot1.value = i + 1;
        	ot1.innerHTML = m.results[i].name;
        	sh.appendChild(ot1);  
      }
   }
   
}

function counthab ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
		cont = m.count;
		page();
   }
}


function listpoke ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);

      for ( i= sp.options.length; i >= 0; i--)
      {
         sp.remove(i);
         IP.innerHTML = " ";
         NP.innerHTML = " ";
         IG.innerHTML = " ";

      }

      ot = document.createElement('option');
      ot.value = '-1';
      ot.innerHTML = "POKEMONS";
      ot.disabled = true;
      ot.selected = true;
      sp.appendChild(ot);

      for(i =0; i<m.pokemon.length;i++)
      { 
        	ot = document.createElement('option');
         ot.value = i;
        	ot.innerHTML = m.pokemon[i].pokemon.name;
        	sp.appendChild(ot);  
         
      } 
   }
}

function showinfo ()
{
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = more;
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/ability/' + sh.value);
	xmlhttp.send();
}

function more ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
      var xmlhttp=new XMLHttpRequest();
	   xmlhttp.onreadystatechange = Poke;
	   xmlhttp.open("GET",m.pokemon[sp.value].pokemon.url);
	   xmlhttp.send();
   }
}
function Poke ()
{
   IG = document.getElementById('IG');
   NP = document.getElementById('NP');
   IP = document.getElementById('IP');
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
		NP.innerHTML = m.name;
      IG.innerHTML= "<img src =' " + m.sprites.front_default + "'id = 'imgpoke'>";
      IP.innerHTML = " ";
      IP.innerHTML = "  ⇾ Height: " + m.height + "<br>" + "  ⇾ Weight: " + m.weight + "<br>";
      for(i =0; i<m.types.length;i++)
      {
         IP.innerHTML += "  ⇾ Types: " + m.types[i].type.name + "<br>";
      }
      for(i =0; i<m.abilities.length;i++)
      {
         IP.innerHTML += "  ⇾ Abilities: " + m.abilities[i].ability.name + "<br>";
      }
      var xmlhttp=new XMLHttpRequest();
	   xmlhttp.onreadystatechange = habi;
	   xmlhttp.open("GET", m.species.url);
	   xmlhttp.send();
	}
}

function habi ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
      IP.innerHTML += "  ⇾ Habitat: " + m.habitat.name;
   }
}


/* pockedex */

function loadEvents5 ()
{
   g = document.getElementById('gen');
   clean = document.getElementById('clean')
   g.addEventListener('change', loadgenerations);
   clean.addEventListener('click', cleardiv);
   card = document.getElementById('page');

   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = processJSON5;
	xmlhttp.open("GET",'https://pokeapi.co/api/v2/generation/');
	xmlhttp.send();
   
}

function cleardiv()
{
   card.innerHTML= " ";

}


function processJSON5 ()
{
   if ((this.readyState==4) && (this.status==200))
	{
      var m=JSON.parse(this.responseText);
      for(i =0; i<m.results.length;i++)
      {
        	o = document.createElement('option');
        	o.value = i +1;
        	o.innerHTML = m.results[i].name;
         g.appendChild(o);
      }
   }
}

function loadgenerations ()
{

      var xmlhttp=new XMLHttpRequest();
	   xmlhttp.onreadystatechange = species;
	   xmlhttp.open("GET",'https://pokeapi.co/api/v2/generation/' + g.value);
	   xmlhttp.send();

}

function species ()
{
   if ((this.readyState==4) && (this.status==200))
	{
		listapokemons=JSON.parse(this.responseText);
      indicepokemon=0;
      totalpokemongeneracion=listapokemons.pokemon_species.length;
      mostrarPokemonGeneracion();
     
   }
}

function mostrarPokemonGeneracion()
{
   var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = getimage;
	xmlhttp.open("GET",listapokemons.pokemon_species[indicepokemon].url);
	xmlhttp.send();
}


function getimage()
{
   if ((this.readyState==4) && (this.status==200))
	{
		var m=JSON.parse(this.responseText);
      
      var xmlhttp=new XMLHttpRequest();
	   xmlhttp.onreadystatechange = showimage;
	   xmlhttp.open("GET",m.varieties[0].pokemon.url);
	   xmlhttp.send();
   }
}

function showimage ()
{

   if ((this.readyState==4) && (this.status==200))
	{

      
         var m=JSON.parse(this.responseText);
         card.innerHTML+= "<div id="+listapokemons.pokemon_species[indicepokemon].name+" class=divpokemon>"+listapokemons.pokemon_species[indicepokemon].name + "<img id=igpk src='"+m.sprites.front_default+"'/>" + "</div>";
        
        if (indicepokemon<totalpokemongeneracion-1)
        {
            indicepokemon++;
            mostrarPokemonGeneracion();
        }
   }
   
}
